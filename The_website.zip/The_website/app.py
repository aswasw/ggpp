from flask import Flask,render_template,request
import mysql.connector
from mysql.connector import Error
app = Flask(__name__)
import tweepy  # This will give an error if tweepy is not installed properly
from tweepy import OAuthHandler
import json
import os
import re
import string
import GetOldTweets3 as got # Twitter only allow retrive tweets the week tweet , so use these library to retrive the years tweets
from pyspark.ml import PipelineModel
from pyspark.shell import spark
import nltk
from nltk.corpus import stopwords
import pyarabic.araby as araby
from nltk.stem import SnowballStemmer
stemmer = SnowballStemmer("arabic")




@app.route("/")
def main():# Method for home
    return render_template('index.html')

@app.route('/Compare')#Method for enter the serach keyowrd
def Compare():
    
    return render_template('Compare1.html')

@app.route('/Compare2')#Method do retrive tweets , preprocessing , classify
def Compare2():
    search = request.args.get('keyword')# The value that user enter it
    y=0

    mydb = mysql.connector.connect(user='root', password='1234',
                                host='localhost',
                                database='S_A_D') # Connect to data base

    mycursor = mydb.cursor()


# Check if the keyword is searched before and stored in database 
    sql = "SELECT * FROM keyy2 WHERE keyyword =('%s') AND year=('%s')"%(search,"2017")

    mycursor.execute(sql)

    myresult = mycursor.fetchall()

    for x in myresult:
        print(x)
        y=y+1
        print(y)
   
        key = x[0]
        pos = x[1]
        neg= x[2]
        net = x[3]

        x1=pos
        print(x1)
        y1=neg
        z1=net
# Check if the keyword is searched before and stored in database 
    sql = "SELECT * FROM keyy2 WHERE keyyword =('%s') AND year=('%s')"%(search,"2018")

    mycursor.execute(sql)

    myresult = mycursor.fetchall()

    for x in myresult:
        print(x)
        y=y+1
        print(y)
   
        key = x[0]
        pos = x[1]
        neg= x[2]
        net = x[3]

        x2=pos
        y2=neg
        z2=net
# Check if the keyword is searched before and stored in database 
    sql = "SELECT * FROM keyy2 WHERE keyyword =('%s') AND year=('%s')"%(search,"2019")

    mycursor.execute(sql)

    myresult = mycursor.fetchall()

    for x in myresult:
        print(x)
        y=y+1
        print(y)
   
        key = x[0]
        pos = x[1]
        neg= x[2]
        net = x[3]
        x3=pos
        y3=neg
        z3=net

    if(y==3): #iF it is in database only draw get the result value from databse

      import numpy as np
      import matplotlib.pyplot as plt
      bar1 = []
      bar2 = []
      bar3 = []


 
      counter1 = 0
      counter2 = 0
      counter3 = 0

      counter1 = x1
      counter2 = y1
      counter3 = z1
      bar1.append(counter1)
      bar2.append(counter2)
      bar3.append(counter3)
      counter1 = 0
      counter2 = 0
      counter3 = 0

      counter1 = 0
      counter2 = 0
      counter3 = 0

      counter1 = x2
      counter2 = y2
      counter3 = z2
      bar1.append(counter1)
      bar2.append(counter2)
      bar3.append(counter3)
      counter1 = 0
      counter2 = 0
      counter3 = 0

      counter1 = 0
      counter2 = 0
      counter3 = 0

      counter1 = x3
      counter2 = y3
      counter3 = z3
      bar1.append(counter1)
      bar2.append(counter2)
      bar3.append(counter3)
      counter1 = 0
      counter2 = 0
      counter3 = 0

      barWidth = 0.25
      bars1 = bar1
      bars2 = bar2
      bars3 = bar3

# The x position of bars
      r1 = np.arange(len(bars1))
      r2 = [x + barWidth for x in r1]
      r3 = [x + barWidth for x in r2]

# Create Positive bars
      plt.bar(r1, bars1, width=barWidth, color='#0489B1', label='Negative')
# Create Neutral bars
      plt.bar(r3, bars3, width=barWidth, color='#A4A4A4', label='Positive')
# Create Negative bars
      plt.bar(r2, bars2, width=barWidth, color='#0B3861', label='Neutral')

      plt.xticks([r + barWidth for r in range(len(bars1))], ['2017', '2018', '2019'])
      plt.ylabel('Number of Tweets')
      plt.legend()

# Show graphic
      #os.remove('/Users/jodharb/Desktop/Final17/static/amm2.png')
      plt.savefig('/Users/jodharb/Desktop/Final17/static/amm3.png')# Save the classify image

    else :# If it is not in database do retive tweets , preprocessing , classify
        print("not")
        model2 = PipelineModel.load("TheModel")# Use the model
        tweetCriteria = got.manager.TweetCriteria().setQuerySearch(search).setSince("2017-04-10").setUntil("2017-04-11").setMaxTweets(20)
        for i in range(0,20):
            tweet = got.manager.TweetManager.getTweets(tweetCriteria)[i]# Get tweets in 2017
            print(tweet.text)
            with open("2017_tweets.txt","a") as f_input:# Write in the file
                 f_input.write("{"+'"text"'+":"+'"'+tweet.text+'"'+ "}")
                 f_input.write("\n")

        with open('2017_tweets.txt','r') as f_input, open('tweets.txt', 'w') as f_output:
            for line in f_input:
                st = line
                searchStr = '"}'
                searchStr2 = '"text": "'
                text= st[st.find(searchStr2) + len(searchStr2): st.find(searchStr)]  # From text filed until the end
        # Remove @ ,http , #
                text = re.sub(r"(?:\@|https?\://)\S+", "", text)
                text = re.sub(r"(?:\#)\S+", "", text)
        # Remove english text and numbers
                text = re.sub(r'[a-zA-Z0-9]+', " ", text)
        # Remove english , and :
                text = re.sub(r'[,]+', " ", text)
                text = re.sub(r'[:]+', " ", text)
        # Remove dublicate letters like : مبروووووك= مبرووك
        # text = re.sub(r'(.)\1+', r'\1', text)
                fainaltext = re.sub(r'(.)\1+', r'\1\1', text)
        # Write to file
                f_output.write("{" + '"text"' + ":" +fainaltext+'"'+"}")
                f_output.write("\n")

# Remove stop word and punctuation ٍ ُ ٌ ِ ًَ ّْ
        with open('tweets.txt', 'r') as inFile, open('removeStopWordFile.txt', 'w') as outFile:
            for line in inFile.readlines():
               print(" ".join([word for word in line.split()
                        if word not in stopwords.words('arabic', 'UTF-8')]), file=outFile)

        inFile.close()
        outFile.close()

        with open('removeStopWordFile.txt', 'r') as f_input, open('RemoveT&T.txt', 'w') as f_output:
            for line in f_input:
                st = line
        # Remove ً
                x = araby.strip_tatweel(st)
                y = araby.strip_tashkeel(x)
        
        # print(y)
                f_output.write(y)
            
        f_input.close()
        f_output.close()

        with open('RemoveT&T.txt', 'r') as f_input, open('steam.txt', 'w') as f_output:
            for line in f_input.read().split("\n"):
        
                sentence = u"" + line
                for word in sentence.split(" "):
                    if word[-1:] == 'ة':
                       word = word[:-1] + 'ه'
                       print(word)
                       stem = stemmer.stem(word)
                       print(stem)
                       f_output.write(str(stem) + " ")
            # f_output.write("\n")
                    else:
                       stem = stemmer.stem(word)
                       print(stem)
                       f_output.write(str(stem) + " ")

                f_output.write("\n")
        f_input.close()
        f_output.close()
    
        with open('steam.txt','r') as f_input, open('final2017.json', 'w') as f_output:
            for line in f_input:
                st = line
                searchStr = '"}'
                searchStr2 = '"text": "'
                text= st[st.find(searchStr2) + len(searchStr2): st.find(searchStr)]  # From text filed until the end
                fainaltext = text.replace('"',' ')
        # Write to file
                f_output.write("{" + '"text"' + ":" +'"'+fainaltext+'"'+"}")
                f_output.write("\n")


             

        tweetCriteria = got.manager.TweetCriteria().setQuerySearch(search).setSince("2018-04-10").setUntil("2018-04-11").setMaxTweets(20)
        for i in range(0,20):
            tweet = got.manager.TweetManager.getTweets(tweetCriteria)[i]# Get tweets in 2018
            print(tweet.text)
            with open("2018_tweets.txt","a") as f_input:#Write to the file
                 f_input.write("{"+'"text"'+":"+'"'+tweet.text+'"'+ "}")
                 f_input.write("\n")

        with open('2018_tweets.txt','r') as f_input, open('tweets.txt', 'w') as f_output:
            for line in f_input:
                st = line
                searchStr = '"}'
                searchStr2 = '"text": "'
                text= st[st.find(searchStr2) + len(searchStr2): st.find(searchStr)]  # From text filed until the end
        # Remove @ ,http , #
                text = re.sub(r"(?:\@|https?\://)\S+", "", text)
                text = re.sub(r"(?:\#)\S+", "", text)
        # Remove english text and numbers
                text = re.sub(r'[a-zA-Z0-9]+', " ", text)
        # Remove english , and :
                text = re.sub(r'[,]+', " ", text)
                text = re.sub(r'[:]+', " ", text)
        # Remove dublicate letters like : مبروووووك= مبرووك
        # text = re.sub(r'(.)\1+', r'\1', text)
                fainaltext = re.sub(r'(.)\1+', r'\1\1', text)
        # write to file
                f_output.write("{" + '"text"' + ":" +fainaltext+'"'+"}")
                f_output.write("\n")

# Remove stop word and punctuation ٍ ُ ٌ ِ ًَ ّْ
        with open('tweets.txt', 'r') as inFile, open('removeStopWordFile.txt', 'w') as outFile:
            for line in inFile.readlines():
               print(" ".join([word for word in line.split()
                        if word not in stopwords.words('arabic', 'UTF-8')]), file=outFile)

        inFile.close()
        outFile.close()

        with open('removeStopWordFile.txt', 'r') as f_input, open('RemoveT&T.txt', 'w') as f_output:
            for line in f_input:
                st = line
        # Remove ً
                x = araby.strip_tatweel(st)
                y = araby.strip_tashkeel(x)
        
        # print(y)
                f_output.write(y)
            
        f_input.close()
        f_output.close()

        with open('RemoveT&T.txt', 'r') as f_input, open('steam.txt', 'w') as f_output:
            for line in f_input.read().split("\n"):
        
                sentence = u"" + line
                for word in sentence.split(" "):
                    if word[-1:] == 'ة':
                       word = word[:-1] + 'ه'
                       print(word)
                       stem = stemmer.stem(word)
                       print(stem)
                       f_output.write(str(stem) + " ")
            # f_output.write("\n")
                    else:
                       stem = stemmer.stem(word)
                       print(stem)
                       f_output.write(str(stem) + " ")

                f_output.write("\n")
        f_input.close()
        f_output.close()
    
        with open('steam.txt','r') as f_input, open('final2018.json', 'w') as f_output:
            for line in f_input:
                st = line
                searchStr = '"}'
                searchStr2 = '"text": "'
                text= st[st.find(searchStr2) + len(searchStr2): st.find(searchStr)]  # From text filed until the end
                fainaltext = text.replace('"',' ')
        # Write to file
                f_output.write("{" + '"text"' + ":" +'"'+fainaltext+'"'+"}")
                f_output.write("\n")

        tweetCriteria = got.manager.TweetCriteria().setQuerySearch(search).setSince("2019-04-10").setUntil("2019-04-11").setMaxTweets(20)
        for i in range(0,20):
            tweet = got.manager.TweetManager.getTweets(tweetCriteria)[i]# Get tweets in 2019
            print(tweet.text)
            with open("2019_tweets.txt","a") as f_input:#Write to the file
                 f_input.write("{"+'"text"'+":"+'"'+tweet.text+'"'+ "}")
                 f_input.write("\n")

        with open('2019_tweets.txt','r') as f_input, open('tweets.txt', 'w') as f_output:
            for line in f_input:
                st = line
                searchStr = '"}'
                searchStr2 = '"text": "'
                text= st[st.find(searchStr2) + len(searchStr2): st.find(searchStr)]  # From text filed until the end
        # Remove @ ,http , #
                text = re.sub(r"(?:\@|https?\://)\S+", "", text)
                text = re.sub(r"(?:\#)\S+", "", text)
        # Remove english text and numbers
                text = re.sub(r'[a-zA-Z0-9]+', " ", text)
        # Remove english , and :
                text = re.sub(r'[,]+', " ", text)
                text = re.sub(r'[:]+', " ", text)
        # Remove dublicate letters like : مبروووووك= مبرووك
        # text = re.sub(r'(.)\1+', r'\1', text)
                fainaltext = re.sub(r'(.)\1+', r'\1\1', text)
        # write to file
                f_output.write("{" + '"text"' + ":" +fainaltext+'"'+"}")
                f_output.write("\n")

# Remove stop word and punctuation ٍ ُ ٌ ِ ًَ ّْ
        with open('tweets.txt', 'r') as inFile, open('removeStopWordFile.txt', 'w') as outFile:
            for line in inFile.readlines():
               print(" ".join([word for word in line.split()
                        if word not in stopwords.words('arabic', 'UTF-8')]), file=outFile)

        inFile.close()
        outFile.close()

        with open('removeStopWordFile.txt', 'r') as f_input, open('RemoveT&T.txt', 'w') as f_output:
            for line in f_input:
                st = line
        # Remove ً
                x = araby.strip_tatweel(st)
                y = araby.strip_tashkeel(x)
        
        # print(y)
                f_output.write(y)
            
        f_input.close()
        f_output.close()

        with open('RemoveT&T.txt', 'r') as f_input, open('steam.txt', 'w') as f_output:
            for line in f_input.read().split("\n"):
        
                sentence = u"" + line
                for word in sentence.split(" "):
                    if word[-1:] == 'ة':
                       word = word[:-1] + 'ه'
                       print(word)
                       stem = stemmer.stem(word)
                       print(stem)
                       f_output.write(str(stem) + " ")
            # f_output.write("\n")
                    else:
                       stem = stemmer.stem(word)
                       print(stem)
                       f_output.write(str(stem) + " ")

                f_output.write("\n")
        f_input.close()
        f_output.close()
    
        with open('steam.txt','r') as f_input, open('final2019.json', 'w') as f_output:
            for line in f_input:
                st = line
                searchStr = '"}'
                searchStr2 = '"text": "'
                text= st[st.find(searchStr2) + len(searchStr2): st.find(searchStr)]  # From text filed until the end
                fainaltext = text.replace('"',' ')
        # write to file
                f_output.write("{" + '"text"' + ":" +'"'+fainaltext+'"'+"}")
                f_output.write("\n")


        from pyspark.sql import SparkSession
        jobDir = 'final2017.json' # New data without label
        tweets = spark.read.json([jobDir])
        tweets.count()
        tweets = tweets.select("text")
        df= model2.transform(tweets)

        jobDir = 'final2018.json' # New data without label
        tweets = spark.read.json([jobDir])
        tweets.count()
        tweets = tweets.select("text")
        df2= model2.transform(tweets)

        jobDir = 'final2019.json' # New data without label
        tweets = spark.read.json([jobDir])
        tweets.count()
        tweets = tweets.select("text")
        df3= model2.transform(tweets)#Use the model

        x1=df.filter(df['prediction'] == 0).count() #Count the number of prediction 0 in 2017
        y1=df.filter(df['prediction'] == 1).count()#Count the number of prediction 1 in 2017
        z1=df.filter(df['prediction'] == 2).count()#Count the number of prediction 1 in 2017
        print(x1)

        x2=df2.filter(df2['prediction'] == 0).count()#Count the number of prediction 0 in 2018
        y2=df2.filter(df2['prediction'] == 1).count()#Count the number of prediction 1 in 2018
        z2=df2.filter(df2['prediction'] == 2).count()#Count the number of prediction 2 in 2018
        print(x2)
        x3=df3.filter(df3['prediction'] == 0).count()#Count the number of prediction 0 in 2019
        y3=df3.filter(df3['prediction'] == 1).count()#Count the number of prediction 1 in 2019
        z3=df3.filter(df3['prediction'] == 2).count()#Count the number of prediction 2 in 2019
        print(x3)


        #Draw the result
        import numpy as np
        import matplotlib.pyplot as plt
        bar1 = []
        bar2 = []
        bar3 = []


 
        counter1 = 0
        counter2 = 0
        counter3 = 0

        counter1 = x1
        counter2 = y1
        counter3 = z1
        bar1.append(counter1)
        bar2.append(counter2)
        bar3.append(counter3)
        counter1 = 0
        counter2 = 0
        counter3 = 0

        counter1 = 0
        counter2 = 0
        counter3 = 0

        counter1 = x2
        counter2 = y2
        counter3 = z2
        bar1.append(counter1)
        bar2.append(counter2)
        bar3.append(counter3)
        counter1 = 0
        counter2 = 0
        counter3 = 0

        counter1 = 0
        counter2 = 0
        counter3 = 0

        counter1 = x3
        counter2 = y3
        counter3 = z3
        bar1.append(counter1)
        bar2.append(counter2)
        bar3.append(counter3)
        counter1 = 0
        counter2 = 0
        counter3 = 0

        barWidth = 0.25
        bars1 = bar1
        bars2 = bar2
        bars3 = bar3

# The x position of bars
        r1 = np.arange(len(bars1))
        r2 = [x + barWidth for x in r1]
        r3 = [x + barWidth for x in r2]

# Create Positive bars
        plt.bar(r1, bars1, width=barWidth, color='#0489B1', label='Negative')
# Create Neutral bars
        plt.bar(r3, bars3, width=barWidth, color='#A4A4A4', label='Positive')
# Create Negative bars
        plt.bar(r2, bars2, width=barWidth, color='#0B3861', label='Neutral')

        plt.xticks([r + barWidth for r in range(len(bars1))], ['2017', '2018', '2019'])
        plt.ylabel('Number of Tweets')
        plt.legend()

        #os.remove('/Users/jodharb/Desktop/Final17/static/amm2.png')
        plt.savefig('/Users/jodharb/Desktop/Final17/static/amm3.png')# save the classify image
      
    
        
        mydb = mysql.connector.connect(user='root', password='1234',
                                host='localhost',
                                database='S_A_D')

        mycursor = mydb.cursor()
#Insert the result in database
        sql = "INSERT INTO keyy2 (keyyword,pos,nega,neu,year) VALUES (%s, %s,%s, %s, %s)"
        val = (search,y1,x1,z1,"2017")
        print(search)
        mycursor.execute(sql, val)
        mydb.commit()

        mydb = mysql.connector.connect(user='root', password='1234',
                                host='localhost',
                                database='S_A_D')

        mycursor = mydb.cursor()
#Insert the result in database
        sql = "INSERT INTO keyy2 (keyyword,pos,nega,neu,year) VALUES (%s, %s,%s, %s, %s)"
        val = (search,y2,x2,z2,"2018")
        print(search)

        mycursor.execute(sql, val)
        mydb.commit()

        mydb = mysql.connector.connect(user='root', password='1234',
                                host='localhost',
                                database='S_A_D')

        mycursor = mydb.cursor()
#Insert the result in database
        sql = "INSERT INTO keyy2 (keyyword,pos,nega,neu,year) VALUES (%s, %s,%s, %s, %s)"
        val = (search,y3,x3,z3,"2019")
        print(search)

        mycursor.execute(sql, val)
        mydb.commit()

        open('tweets20.json', 'w').close()# Delete the file


    return render_template('Compare2.html')#Call Compare2.html file to dispaly the result image


@app.route('/Search_for_semmantic') #Method for enter the serach keyowrd
def Search_for_semmantic():
    
    return render_template('Search_for_semmantic1.html')


@app.route('/Search_for_semmantic2')#Method do retrive tweets , preprocessing , classify
def Search_for_semmantic2():
    search = request.args.get('keyword')
    y=0


    mydb = mysql.connector.connect(user='root', password='1234',
                                host='localhost',
                                database='S_A_D')

    mycursor = mydb.cursor()

    # Check if the keyword is searched before and stored in database 
    sql = "SELECT * FROM keyy WHERE keyyword =('%s')"%(search)

    mycursor.execute(sql)

    myresult = mycursor.fetchall()

    for x in myresult:
        print(x)
        y=y+1
        print(y)
    if(y==1):  #If it is in database only draw get the result value from databse
       print("exit")
       for x in myresult:
           key = x[0]
           pos = x[1]
           neg= x[2]
           net = x[3]
       labels = 'Negative', 'Positive', 'Neutral'
       sizes = [neg,pos,net]
       import matplotlib.pyplot as plt
       fig1, ax1 = plt.subplots()
       colors=['#0489B1','#A4A4A4','#0B3861']
       yourtext = key

## Use matplotlib to plot the chart
       ax1.pie(sizes, labels=labels, colors=colors , autopct='%1.1f%%',
             shadow=True, startangle=90)
       ax1.axis('equal')
       
       #os.remove('/Users/jodharb/Desktop/Final17/static/amm2.png')
       fig1.savefig('/Users/jodharb/Desktop/Final17/static/amm3.png')# Save the classify image

       plt.close(fig1)# Use the model to classify the new data , # get the predictions of new data
 
    
    else: # If it is not in database do retive tweets , preprocessing , classify
        consumer_key = 'luCMgoolgODpFH9rxcvLbRqYt'
        consumer_secret = 'lW9fERVDfcgoq3aqVDYpbUNGkKUUFquwpQYrLvlaXzeekpvkgZ'
        access_token = '750950262098059268-riOExqjYPhUTJAe4OHW9F7aYfK2ljuQ'
        access_token_secret = 'GE4K0zqwyBi50k5Ma3xFSP44zYd1HiM5ncL1gGaDscu5K'
#Access tokens
        auth = tweepy.auth.OAuthHandler(consumer_key, consumer_secret)
        auth.set_access_token(access_token, access_token_secret)

        api = tweepy.API(auth)
# Open/Create a file to append data
    
        for tweet in tweepy.Cursor(api.search,q=search,lang="ar").items(200):
            with open('tweets20.json', 'a') as f:  
               print("1")
               f.write(str(tweet._json))
               f.write("\n")


        with open('tweets20.json','r') as f_input, open('tweets200.json', 'w') as f_output:
             for line in f_input:
                 text = re.sub("\'", "\"", line)
                 text = re.sub('"}',' "}', text)#Make space between " and }
        # write to file
                 f_output.write(text)
        f_input.close()
        f_output.close()

        with open('tweets200.json','r') as f_input, open('tweets2000.json', 'w') as f_output:

             for line in f_input:
              
                st= line
                searchStr = 'id'
                searchStr2 = 'text":'
                searchStr3 = '"truncated":'
                created_at= st[:st.find(searchStr)] # From created_at filed until Text

                text = st[st.find(searchStr2):st.find(searchStr3)]# From text filed until the end
                z=created_at+text+"}"
                text = re.sub('", }',' "}',z)
                f_output.write(text)
                f_output.write("\n")

        with open('tweets2000.json', 'r') as f:
            txt = f.read()
        with open('tweets.txt', 'w') as f:
    # write to file
             f.write(txt)



        with open('tweets.txt','r') as f_input, open('tweetjsonformat.txt', 'w') as f_output:
    
            for line in f_input:
               st= line
               text = re.sub("\'", "\"",line)
               text = re.sub('"}',' "}', text)
        #write to file
               f_output.write(text)
               
        f_input.close()
        f_output.close()


        with open('tweetjsonformat.txt','r') as f_input, open('clean_tweet.txt', 'w') as f_output:
    
            for line in f_input:
        
               st= line
               searchStr = 'text'
               searchStr2 = 'text":'
               x= st[:st.find(searchStr)]
        # Remove @ ,http , #
               text = st[st.find(searchStr2) + len(searchStr2):]
        #print(text)
               text = re.sub(r"(?:\@|https?\://)\S+", "", text)
        
               text=re.sub(r"(?:\#)\S+", "", text)
        #Remove english text and numbers
               text=re.sub(r'[a-zA-Z0-9]+'," ",text)

        
               text = re.sub(r'[,]+', " ", text)
               text = re.sub(r'[:]+', " ", text)
               text=text.replace("\\", "")
        
        #remove dublicate letters like : مبروووووك= مبرووك
        #text = re.sub(r'(.)\1+', r'\1', text)
               fainalltext = re.sub(r'(.)\1+', r'\1\1',text)
               print(fainalltext)
        #print(x+searchStr2+text)
        #  z=x+searchStr2+text
        # if(z=="text ")
        #write to file
               f_output.write(x+searchStr2+fainalltext)
            
        f_input.close()
        f_output.close()



# Remove stop word and punctuation ٍ ُ ٌ ِ ًَ ّْ
        with open('clean_tweet.txt', 'r') as inFile, open('removeStopWordFile.txt', 'w') as outFile:
            for line in inFile.readlines():
                print(" ".join([word for word in line.split()
                        if word not in stopwords.words('arabic', 'UTF-8')]), file=outFile)

        inFile.close()
        outFile.close()

        with open('removeStopWordFile.txt', 'r') as f_input, open('RemoveT&T.txt', 'w') as f_output:
            for line in f_input:
                st = line
        # Remove ً
                x = araby.strip_tatweel(st)
                y = araby.strip_tashkeel(x)
        
        # print(y)
                f_output.write(y)
            
        f_input.close()
        f_output.close()

        with open('RemoveT&T.txt', 'r') as f_input, open('steam.txt', 'w') as f_output:
            for line in f_input.read().split("\n"):
        
                sentence = u"" + line
                for word in sentence.split(" "):
                    if word[-1:] == 'ة':
                       word = word[:-1] + 'ه'
                       print(word)
                       stem = stemmer.stem(word)
                       print(stem)
                       f_output.write(str(stem) + " ")
            # f_output.write("\n")
                    else:
                       stem = stemmer.stem(word)
                       print(stem)
                       f_output.write(str(stem) + " ")

                f_output.write("\n")
        f_input.close()
        f_output.close()
    
        with open('steam.txt','r') as f_input, open('final20.json', 'w') as f_output:
            for line in f_input:
                st = line
                searchStr = '"}'
                searchStr2 = '"text": "'
                text= st[st.find(searchStr2) + len(searchStr2): st.find(searchStr)]  # From text filed until the end
                fainaltext = text.replace('"',' ')
        # write to file
                f_output.write("{" + '"text"' + ":" +'"'+fainaltext+'"'+"}")
                f_output.write("\n")

        from pyspark.ml import PipelineModel
        from pyspark.shell import spark
        model2 = PipelineModel.load("TheModel")
    #Data Ingestion and Extraction
        from pyspark.sql import SparkSession
        jobDir = "final20.json" # New data without label
        tweets = spark.read.json([jobDir])
        tweets.count() #Load the saved model # use the model to classify the new data
        tweets = tweets.select("text")
        tweets.printSchema()
        df = model2.transform(tweets)
        df.select("text","prediction","words").show(20,False)
        import matplotlib.pyplot as plt # Use matplotlib to draw the classification result in pichart
        import pandas as pd
        x=df.filter(df['prediction'] == 0).count() #Count the prediction 0
        y=df.filter(df['prediction'] == 1).count() #Count the prediction 1
        z=df.filter(df['prediction'] == 2).count() #Count the prediction 2
        labels ='Negative','Positive', 'Neutral'
        sizes = [x, y, z]
        if x > y :
            a=1.0
        explode = (a, 0, 0)
        fig1, ax1 = plt.subplots()
        colors=['#0489B1','#A4A4A4','#0B3861']
        yourtext = "الأم"

## Use matplotlib to plot the chart
        ax1.pie(sizes, labels=labels, colors=colors , autopct='%1.1f%%',shadow=True, startangle=90)
        ax1.axis('equal')

        #os.remove('/Users/jodharb/Desktop/Final17/static/amm2.png')
        plt.savefig('/Users/jodharb/Desktop/Final17/static/amm3.png')# Save the classify image
        plt.close(fig1)
         
        print("start mysql")
        mydb = mysql.connector.connect(user='root', password='1234',
                                host='localhost',
                                database='S_A_D')

        mycursor = mydb.cursor()
        #Insert the result in database
        sql = "INSERT INTO keyy (keyyword,positive,negative,neutral) VALUES (%s, %s,%s, %s)"
        val = (search,y,x,z)
        print(search)
        print(x)
        print(y)
        print(z)
        mycursor.execute(sql, val)
        mydb.commit()

        open('tweets20.json', 'w').close()

    return render_template('Search_for_semmantic2.html')#Call Search_for_semmantic2.html file to dispaly the result image



if __name__ == "__main__":
    app.run()
